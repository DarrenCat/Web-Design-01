(function(){(window.goog=window.goog||{}).inherits=function(a,c){function b(){}b.prototype=c.prototype;a.prototype=new b;a.prototype.constructor=a};}).call(this);
